package com.learning.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginFormServlet
 */
@WebServlet(description = "Servlet created with XML setup", urlPatterns = { "/LoginForm" })
public class LoginFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String jsone ="{ \"Name\": \"Foo\", \"Id\": 1234, \"Rank\": 7 }";
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Get executed");
		response.setContentType("application/json");
	    response.setCharacterEncoding("UTF-8");
	    response.getWriter().write(jsone);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String department = request.getParameter("dept");
		String[] year = request.getParameterValues("year");
		for(int i=0;i<year.length;i++)
		{
		System.out.println(name + " " + department + " " + year[i]);
		}
	}

}
