package com.login.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.bean.loginbean;
import com.login.service.loginservice;

/**
 * Servlet implementation class Loginservlet
 */
@WebServlet("/login")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String user = request.getParameter("user");
		String Password = request.getParameter("pass");
		loginservice log = new loginservice();
		boolean result = log.authenicate(user, Password);
		if(result){
			loginbean loginuser = log.getdetail(user);
			request.getSession().setAttribute("user", loginuser);
			request.setAttribute("user", user);
			//response.sendRedirect("greeting.jsp");
			RequestDispatcher req = request.getRequestDispatcher("greeting.jsp");
			req.forward(request, response);
			return;
		}else{
			response.sendRedirect("Login.jsp");
			return;
		}
	}

}
