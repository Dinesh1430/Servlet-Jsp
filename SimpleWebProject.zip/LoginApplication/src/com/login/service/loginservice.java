package com.login.service;

import java.util.*;

import com.login.bean.loginbean;

public class loginservice {
	HashMap<String,String>  map = new HashMap<String,String>();
	
	public loginservice(){
	map.put("Dinesh","Dinesh");	
	map.put("Darun","Darun");
	map.put("Darun","Darun");
	}
	
	public boolean authenicate(String name,String Password){
		if(Password == null || Password.trim() == ""){
			return false;
		}
		if(map.containsValue(name)){
			System.out.println("Sucess");
		}
		return true;	
	}
	
	public loginbean getdetail(String loginuser){
		 loginbean user = new loginbean();
		 user.setUsername(map.get(loginuser));
		 return user;
	}
}
